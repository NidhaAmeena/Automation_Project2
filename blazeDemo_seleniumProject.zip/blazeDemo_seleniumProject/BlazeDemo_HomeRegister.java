package blazeDemo_seleniumProject;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BlazeDemo_HomeRegister {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method st
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nidha\\OneDrive\\Documents\\Browser Extension\\chromedriver-win64.exe");
		WebDriver driver=new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		driver.get("https://blazedemo.com/");
		Thread.sleep(2000);
		
		driver.findElement(By.linkText("home")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Register")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("name")).sendKeys("Earla Saiprasanna");
		Thread.sleep(2000);
		driver.findElement(By.id("company")).sendKeys("IBM");
		Thread.sleep(2000);
		driver.findElement(By.id("email")).sendKeys("prasannaachinni06@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Prasu@12");
		Thread.sleep(2000);
		driver.findElement(By.id("password-confirm")).sendKeys("Prasu@12");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(2000);
		
		driver.close();
		

	}

}
